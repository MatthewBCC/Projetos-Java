// Classe Funcionario.java
public class Funcionario {
	private String cpf;
	private String nome;
	private double salario;
	int tipoFuncionario;

	//Construtor
//	public Funcionario(String cpf, String nome, double salario) {
//		this.cpf = cpf;
//		this.nome = nome;
//		this.salario = salario;
//	}
	
	// Getters e Setters
	public String getCpf() {
		return this.cpf;
	}
	
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	public String getNome() {
		return this.nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public double getSalario() {
		return this.salario;
	}
	
	public void setSalario(double salario) {
		this.salario = salario;
	}
	
	public int getTipoFuncionario() {
		return tipoFuncionario;
	}
	
	public void setTipoFuncionario(int tipoFuncionario) {
		this.tipoFuncionario = tipoFuncionario;
	}
	
	public double getBonificacao() {
		if (tipoFuncionario == 0){
			return salario*10/100;
		} else if(tipoFuncionario == 1) {
			return salario;
		}
		return 0.0;
	}
	
}// fim da classe Funcionario

