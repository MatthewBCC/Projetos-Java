
public class TestaFuncionario {
	public static void main(String[] args) {
		Funcionario f1 = new Funcionario();
		f1.setNome("Jos�");
		f1.setSalario(1000);
		f1.setTipoFuncionario(0);
		System.out.println("Bonificacao do " + f1.getNome() + " � " + f1.getBonificacao());
		
		Funcionario g1 = new Funcionario();
		g1.setNome("Seu Armando");
		g1.setSalario(10000.0);
		g1.setTipoFuncionario(1);
		System.out.println("Bonificacao do " + g1.getNome() + " � " + g1.getBonificacao());
	}
}
