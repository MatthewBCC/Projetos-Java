public class TestaGetESet {
	public static void main(String[] args) {
		Conta conta = new Conta();
		conta.setNumero(1234);
		System.out.println(conta.getNumero());
		Cliente Paulo = new Cliente();
		Paulo.setNome("Paulo");
		conta.setTitular(Paulo);
		System.out.println(conta.getTitular().getNome());
		
		
	}

}
